//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "math.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
double K_L, KFiMin, KFiMax, K_w, KGreen;

void Rec(double x, double y, double L, double fi, double w, double gr, int DGr) {
 Form1->Canvas->MoveTo(x,y);
 double x2=x+L*sin(fi*M_PI/180), y2=y-L*cos(fi*M_PI/180);
 Form1->Canvas->Pen->Color=gr*256;
 Form1->Canvas->Pen->Width=w;
 Form1->Canvas->LineTo(x2, y2);
 if (L>1)
  {
   Rec(x2,y2,L*K_L, fi+random(KFiMax-KFiMin+1)+KFiMin,  w*K_w, gr+DGr, DGr);
   Rec(x2,y2,L*K_L, fi-(random(KFiMax-KFiMin+1)+KFiMin), w*K_w, gr+DGr, DGr);
  }
}

void __fastcall TForm1::Button1Click(TObject *Sender)
{
 randomize();
 Canvas->Pen->Color=clWhite;
 Canvas->Brush->Color=clWhite;
 Canvas->Rectangle(0,0,400,450);
 K_L=Edit1->Text.ToDouble();
 KFiMin=Edit2->Text.ToDouble();
 KFiMax=Edit3->Text.ToDouble();
 K_w=Edit4->Text.ToDouble();
 KGreen=Edit5->Text.ToDouble();
 Rec(200, 400, 100, 0, 4, 0, KGreen);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
 double y, dy, x;
 randomize();
 Canvas->Pen->Color=clWhite;
 Canvas->Brush->Color=0xb0ffff;
 Canvas->Rectangle(0,0,400,450);
 K_L=Edit1->Text.ToDouble();
 KFiMin=Edit2->Text.ToDouble();
 KFiMax=Edit3->Text.ToDouble();
 K_w=Edit4->Text.ToDouble();
 KGreen=Edit5->Text.ToInt();
 for (y=150, dy=5; y<=400; y+=dy++)
  Rec(random(350-y/2)+y/4+25, y, y/3, 0, y/50, 0, KGreen*y/400);
}
//---------------------------------------------------------------------------
