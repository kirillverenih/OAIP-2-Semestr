//---------------------------------------------------------------------------

#include <vcl.h>
#include <math.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
double cr,cg,cb, sr,sg,sb, t0;
int X0=200, Y0=400, R=600, YHorizon=360;
double fi;

void __fastcall TForm1::Button1Click(TObject *Sender)
{
 DoubleBuffered=true;
 Image1->Hide();
 Image2->Canvas->Brush->Color=0;
 Image2->Canvas->Rectangle(0,0,Image2->Width,Image2->Height);
 Timer1->Enabled=true;
 Timer2->Enabled=false;
 cr=cg=cb=0;
 sr=0.5;
 sg=0.1;
 sb=0.1;

 Image3->Canvas->Pen->Color=0;
 Image3->Canvas->Brush->Color=0;
 Image3->Canvas->Rectangle(0,0,Image3->Width,Image3->Height);
 fi=0;
 //Image3->Canvas->Pixels[0][Image3->Height-1]=clWhite;

 t0=Now();
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
 int N=50000;
 cr+=0.01;
 cg+=0.004;
 cb+=0.005;
 if (cr>1) cr=1;
 if (cg>1) cg=1;
 if (cb>1) cb=1;
 Label1->Caption=FloatToStrF(cr, ffFixed, 15, 2);
 Label2->Caption=FloatToStrF(cg, ffFixed, 15, 2);
 Label3->Caption=FloatToStrF(cb, ffFixed, 15, 2);
 Label4->Caption=TimeToStr(Now()-t0);

 for(int i=0; i<N; i++) {
  int x=random(Image2->Width);
  int y=random(Image2->Height);
  int c=Image1->Canvas->Pixels[x][y];
  int r=c%256;
  c/=256;
  int g= c%256;
  c/=256;
  int b=c;
  int c2=RGB(r*cr, g*cg, b*cb);
  Image2->Canvas->Pixels[x][y]=c2;

  if(i%(N/3+1)==0 && cr>=0.4) { // ������ ������
   sr+=0.004;
   sg+=0.0015;
   sb+=0.0008;
   if (sr>1) sr=1;
   if (sg>1) sg=1;
   if (sb>0.7) sb=0.7;
   Image3->Canvas->Brush->Color=RGB(255*sr, 255*sg, 255*sb);
   Image3->Canvas->Ellipse(0,0,Image3->Width,Image3->Height);
   fi+=0.0007;
   Image3->Left=X0+R*cos(fi);
   Image3->Top=Y0-R*sin(fi);
   Image3->Canvas->Brush->Color=0;      // �������� ������ �� ����������
   Image3->Canvas->Rectangle(0,YHorizon-Image3->Top,Image3->Width,Image3->Height);
   Repaint();
  }
 }
 //if (cr>=1 && cg>=1 && cb>=1) Timer1->Enabled=false;
}

int C[2000][2000];

//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
 DoubleBuffered=true;
 Image1->Hide();
 Image2->Canvas->Brush->Color=0;
 Image2->Canvas->Rectangle(0,0,Image2->Width,Image2->Height);
 Timer2->Enabled=true;
 Timer1->Enabled=false;
 cr=cg=cb=0;
 sr=0.5;
 sg=0.1;
 sb=0.1;
 for (int x=0; x<Image2->Width; x++)
  for (int y=0; y<Image2->Height; y++)
   C[x][y]= Image1->Canvas->Pixels[x][y];

 Image3->Canvas->Pen->Color=0;
 Image3->Canvas->Brush->Color=0;
 Image3->Canvas->Rectangle(0,0,Image3->Width,Image3->Height);
 fi=0;
 //Image3->Canvas->Pixels[0][Image3->Height-1]=clWhite;
 t0=Now();
}

//---------------------------------------------------------------------------
void __fastcall TForm1::Timer2Timer(TObject *Sender)
{
 int N=50000;
 cr+=0.01;
 cg+=0.004;
 cb+=0.005;
 if (cr>1) cr=1;
 if (cg>1) cg=1;
 if (cb>1) cb=1;
 Label1->Caption=FloatToStrF(cr, ffFixed, 15, 2);
 Label2->Caption=FloatToStrF(cg, ffFixed, 15, 2);
 Label3->Caption=FloatToStrF(cb, ffFixed, 15, 2);
 Label4->Caption=TimeToStr(Now()-t0);
 int XMax=Image2->Width;
 int YMax=Image2->Height;

 for(int i=0; i<N; i++) {
  int x=random(XMax);
  int y=random(YMax);
  int c=C[x][y];
  int r=c%256;
  c/=256;
  int g= c%256;
  c/=256;
  int b=c;
  int c2=RGB(r*cr, g*cg, b*cb);
  Image2->Canvas->Pixels[x][y]=c2;

  if(i%(N/3+1)==0 && cr>=0.4) { // ������ ������
   sr+=0.004;
   sg+=0.0015;
   sb+=0.0008;
   if (sr>1) sr=1;
   if (sg>1) sg=1;
   if (sb>0.7) sb=0.7;
   Image3->Canvas->Brush->Color=RGB(255*sr, 255*sg, 255*sb);
   Image3->Canvas->Ellipse(0,0,Image3->Width,Image3->Height);
   fi+=0.0007;
   Image3->Left=X0+R*cos(fi);
   Image3->Top=Y0-R*sin(fi);
   Image3->Canvas->Brush->Color=0;      // �������� ������ �� ����������
   Image3->Canvas->Rectangle(0,YHorizon-Image3->Top,Image3->Width,Image3->Height);
   Repaint();
  }
 }
 //if (cr>=1 && cg>=1 && cb>=1) Timer1->Enabled=false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
  Image1->Canvas->Pen->Color=RGB(255, 0, 0);
  Image1->Canvas->Brush->Color=RGB(255, 150, 150);
  TPoint a[4] = { Point(121,47), Point(131,67), Point(121,87), Point(111,67) };
  Image1->Canvas->Polygon(a, 3);
}
//---------------------------------------------------------------------------
