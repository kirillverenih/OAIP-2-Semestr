//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused

#include<iostream.h>
#include<stdio.h>

struct T {
 char name[30];
 int age;
} spisok[100];

void QuickSort(T* mas, int L, int R)
{
  if (L>=R) return;  // ���� � ����������� ����� ������� ���� ������� - �����!
  int i,j;
  T r;
  i = L; j = R;
  int x = mas[(L + R)/2].age;
  while (i <= j) {
      	while (mas[i].age < x)  i++;
    	while (mas[j].age > x)  j--;
      	if (i <= j) {
          		r = mas[i];    		// ������������ ��������
			mas[i] = mas[j];
			mas[j] = r;
    		        i++; j--;
         	    }
  }
  QuickSort(mas, L, j);
  QuickSort(mas, i, R);
}

int BinarySearch(T* a, int n, int age)
{
	int i = 0, j = n-1, m;
        while(i < j) {
        	m = (i + j)/2;
        	if (a[m].age < age) i = m+1;
		else  j = m;
        }
        if (a[i].age != age) return -1; 		// ������� �� ������
                  else return i;
}

int main(int argc, char* argv[])
{
        int i,n,age;
        cout<<"Vvedite kolichestvo studentov"<<endl;
        cin>>n;
        for (i=0; i<n; i++) {
                cout<<"Vvedite imya "<<i+1<<"-go studenta:";
                fflush(stdin);
                gets(spisok[i].name);
                cout<<"Vvedite vozrast "<<i+1<<"-go studenta:";
                cin>>spisok[i].age;
        }

        QuickSort(spisok, 0, n-1);
        cout<<"Otsortirovannye svedeniya:"<<endl;
        for (i=0; i<n; i++)
           cout<<i+1<<") "<<spisok[i].name<<"  "<<spisok[i].age<<endl;

        while (1) {
                cout<<"Vvedite iskomyj vozrast, libo 0 dlya vyhoda:";
                cin>>age;
                if (age<=0) break;
                i=BinarySearch(spisok, n, age);
                if (i>=0)
                  cout<<i+1<<") "<<spisok[i].name<<"  "<<spisok[i].age<<endl;
                  else cout<<"Student s vozrastom "<<age<<" ne najden!"<<endl;
        }
        return 0;
}
//---------------------------------------------------------------------------
 