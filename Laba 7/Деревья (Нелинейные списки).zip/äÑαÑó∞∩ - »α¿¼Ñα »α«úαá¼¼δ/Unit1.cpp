//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

Tree *root;

void __fastcall TForm1::Button5Click(TObject *Sender)
{
 StringGrid1->RowCount++;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button6Click(TObject *Sender)
{
 StringGrid1->RowCount--;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  root=List(StrToInt(StringGrid1->Cells[0][0]));
  for (int i=1; i<StringGrid1->RowCount; i++)
    Add_List(root, StrToInt(StringGrid1->Cells[0][i]));
  View_Tree(root, 0);
  View_Tree_T(root);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
  int i=StrToInt(Edit1->Text);
  if (Find_Elem(root, i))
    Memo1->Lines->Add("������� "+IntToStr(i)+" ����!");
    else Memo1->Lines->Add("�������� "+IntToStr(i)+" ���!");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
  int i=0, n=Size_Tree(root);
  int *mas=new int[n];
  Store_Tree(root, &i, mas);
  Make_Blns(&root, 0, n, mas);
  View_Tree_T(root);
  delete mas;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  randomize();
  for (int i=0; i<StringGrid1->RowCount; i++)
    StringGrid1->Cells[0][i]=random(100);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button7Click(TObject *Sender)
{
  int b = StrToInt(Edit1->Text);
  root = Del_Info(root, b);
  View_Tree_T(root);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button8Click(TObject *Sender)
{
  Del_Tree(root);
  root=NULL;
  TreeView1->Items->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
 Write_Tree_Pr(root);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button10Click(TObject *Sender)
{
  Write_Tree_Vozr(root);
}

//---------------------------------------------------------------------------

void __fastcall TForm1::Button11Click(TObject *Sender)
{
 Write_Tree_Obr(root);       
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button9Click(TObject *Sender)
{
 int i=StrToInt(Edit1->Text);
 Add_List(root, i);
 View_Tree_T(root);
}
//---------------------------------------------------------------------------

