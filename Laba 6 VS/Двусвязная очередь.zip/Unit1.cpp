//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
 randomize();
}
//---------------------------------------------------------------------------
struct TZap {
 double x;
 TZap * prev, *next;
} *t;

void Add(TZap *& b, TZap *& e, double x0) {
  TZap * t=new TZap;
  t->x=x0;
  t->next=NULL;
  if (b)
      e->next=t, t->prev=e;
    else
      b=t, t->prev=NULL;
  e=t;
}

double Get(TZap ** b) {
 TZap * t=*b;
 if (!t) {
  ShowMessage("������� �����!");
  Abort();
 }
 double x0=t->x;
 *b=(*b)->next;
 if(*b) (*b)->prev=NULL;
 delete t;
 return x0;
}

TZap *begin, *end;



void __fastcall TForm1::Button1Click(TObject *Sender)
{
 Add(begin, end, Edit1->Text.ToDouble());
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
 Memo1->Lines->Add(Get(&begin));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
  int y=random(21)-10;
  Add(begin, end, y);
  Memo1->Lines->Add(y);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
 TZap * t, *u;
 t=begin;
 while(t) {
   u=t;
   t=t->next;
   if (u->x < 0)
    {
      if (u==begin)
        begin=t;
        else u->prev->next=t;
      if (t)
        t->prev=u->prev;
        else end=u->prev;
      delete u;
    }
 }

}




//---------------------------------------------------------------------------
void __fastcall TForm1::Button5Click(TObject *Sender)
{
 if (!begin) {
  Memo1->Lines->Add("������� �����!");
  return;
 }
 TZap *t;
 bool r=CheckBox1->Checked;
 t= r? end : begin;
 while(t) {
   Memo1->Lines->Add(t->x);
   t= r? t->prev : t->next;
 }
}
//---------------------------------------------------------------------------

